## This is an interview assessment for a data engineer position.
With that said, if you're not part of the interviewing process, kindly look away :)

## File Description:
### main.py:
 - Contains the entire python script required for the assessment, containing functions for table/database creation using SQL, fill tables and handle/process the data involved.
 - Running this single file should be enough, but SQL code files are also included as a means of redundancy.
### line47.sql
 - Creates the table defined in the 1st part of the assesment.
 - The exact query within this file is already included in the main.py script, thus running this should not be necessary, but won't do harm either.
### dataset.csv
 - Well, the source file.
