create table if not exists pivotEvents 
                  (start_timestamp datetime,
                   end_timestamp datetime,
                   duration char)